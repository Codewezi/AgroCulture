<?php
	if(isset($_SESSION['logged_in']) AND $_SESSION['logged_in'] == 1)
	{
		$loginProfile = "My Profile: ". $_SESSION['Username'];
		$logo = "glyphicon glyphicon-user";
		if($_SESSION['Category']!= 1)
		{
			$link = "Login/profile.php";
		}
		else {
				$link = "profileView.php";
		}
	}
	else
	{
		$loginProfile = "Login";
		$link = "index.php";
		$logo = "glyphicon glyphicon-log-in";
	}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <meta charset="UTF-8">
		<title>AgroCulture</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href="bootstrap\css\bootstrap.min.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="bootstrap\js\bootstrap.min.js"></script>
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="login.css"/>
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<link rel="stylesheet" href="indexfooter.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
<style>

    *{
        box-sizing: border-box;
    }
    body{
        background-color: #02894B;
    }
    .govt-schemes-box{
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
        padding: 16px;
        text-align: center;
        background-color: #f1f1f1;
       
        width: 80%;
        margin: auto;
        padding-bottom: 40px;
        margin-bottom: 20px;
    }
.btn-yellow2 {
    
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display : inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}    
.head{
    width: 100%;
    padding: 10px;
    text-align: center;
    color: #f1f1f1;
    margin-bottom: 60px;
    margin-top: 60px;
}
</style>

    
</head>
<body>


<header id="header">
				<h1><a href="index.php">AgroCulture</a></h1>
				<nav id="nav">
					<ul><li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
						
						<li><a href="vegitable-framing.php"><span class="glyphicon glyphicon-grain"> Vegitable-Farming</a></li>
					<li><a href="fruit-farming.php"><span class="glyphicon glyphicon-grain"> Fruit-Farming</a></li>
          <li><a href="grain-farming.php"><span class="glyphicon glyphicon-grain"> Grain-Farming</a></li>
					<li><a href="animal-husbandary.php"><span class="glyphicon glyphicon-grain"> Animal-Husbandary</a></li>
						<li><a href="schems.php"><span class="glyphicon glyphicon-grain"> Govt-Schemes</a></li>
						<li><a href="blogView.php"><span class="glyphicon glyphicon-comment"> Blog</a></li>
						<li><a href="<?= $link; ?>"><span class="<?php echo $logo; ?>"></span><?php echo" ". $loginProfile; ?></a></li>
						
						

					</ul>
				</nav>
			</header>

    <h1 class="head">
        GOVERNMENT - SCHEMES
    </h1>
    

    <div class="govt-schemes-page-content">
        <div class="container">
          <div class="govt-schemes-page-content-inner">
            <div class="govt-schemes-boxs">           
                         
                          <div class="govt-schemes-box">
                            <div class="govt-schemes-box-left">
                              <a href="/en/pn/govt-schemes-details/loan-scheme-for-combine-harvester">
                                <img src="/upload/govt_category/3821-MicrosoftTeams-image(66).jpg" alt="">
                              </a>
                            </div>
                            <div class="govt-schemes-box-body">
                              <div class="row">
                                <div class="col-md-9">
                                  <h3><a href="https://sbi.co.in/web/agri-rural/agriculture-banking/farm-mechanization-loan/combine-harvester-loan#show">Loan Scheme for COMBINE HARVESTER</a></h3>
                                  <p><p><span style="font-size:11.0pt;line-height:&#xA;107%;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;&#xA;mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:&#xA;minor-latin;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;&#xA;mso-ansi-language:EN-GB;mso-fareast-language:EN-US;mso-bidi-language:AR-SA" lang="EN-GB">To enhance the farm mechanization in agriculture</span></p></p>
                                </div>
                                <div class="col-md-3">
                                  <a href="https://sbi.co.in/web/agri-rural/agriculture-banking/farm-mechanization-loan/combine-harvester-loan#show" class="btn-yellow2 w-100">Enquire Now</a>
                                </div>
                              </div>
                            </div>
                          </div>						
                         
                          <div class="govt-schemes-box">
                            <div class="govt-schemes-box-left">
                              <a href="/en/pn/govt-schemes-details/tractor-loan-scheme">
                                <img src="/upload/govt_category/7926-thumbnail_MicrosoftTeams-image(69).jpg" alt="">
                              </a>
                            </div>
                            <div class="govt-schemes-box-body">
                              <div class="row">
                                <div class="col-md-9">
                                  <h3><a href="https://sbi.co.in/web/agri-rural/agriculture-banking/farm-mechanization-loan/tractor-loan/new-tractor-loan-scheme">Tractor Loan Scheme</a></h3>
                                  <p><p><span style="font-size:11.0pt;line-height:&#xA;107%;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;&#xA;mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:&#xA;minor-latin;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;&#xA;mso-ansi-language:EN-GB;mso-fareast-language:EN-US;mso-bidi-language:AR-SA" lang="EN-GB">Farmer should possess a min. land holding of 2 acres.</span></p></p>
                                </div>
                                <div class="col-md-3">
                                  <a href="https://sbi.co.in/web/agri-rural/agriculture-banking/farm-mechanization-loan/tractor-loan/new-tractor-loan-scheme" class="btn-yellow2 w-100">Enquire Now</a>
                                </div>
                              </div>
                            </div>
                          </div>						
                         
                          <div class="govt-schemes-box">
                            <div class="govt-schemes-box-left">
                              <a href="/en/pn/govt-schemes-details/agriculture-gold-loan">
                                <img src="/upload/govt_category/6701-MicrosoftTeams-image(65).jpg" alt="">
                              </a>
                            </div>
                            <div class="govt-schemes-box-body">
                              <div class="row">
                                <div class="col-md-9">
                                  <h3><a href="https://sbi.co.in/web/agri-rural/agriculture-banking/gold-loan/multi-purpose-gold-loan">Agriculture Gold Loan</a></h3>
                                  <p>
                                    
                                    <p><p><span style="font-size:11.0pt;line-height:&#xA;107%;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;&#xA;mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:&#xA;minor-latin;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;&#xA;mso-ansi-language:EN-GB;mso-fareast-language:EN-US;mso-bidi-language:AR-SA" lang="EN-GB">All Farmers-Individuals who are owner cultivators, Agri Entrepreneurs.</span></p></p>
                                </div>
                                <div class="col-md-3">
                                  <a href="https://sbi.co.in/web/agri-rural/agriculture-banking/gold-loan/multi-purpose-gold-loan" class="btn-yellow2 w-100">Enquire Now</a>
                                </div>
                              </div>
                            </div>
                          </div>						
                         
                          <div class="govt-schemes-box">
                            <div class="govt-schemes-box-left">
                              <a href="/en/pn/govt-schemes-details/dairy-development-scheme">
                                <img src="/upload/govt_category/5134-MicrosoftTeams-image(67).jpg" alt="">
                              </a>
                            </div>
                            <div class="govt-schemes-box-body">
                              <div class="row">
                                <div class="col-md-9">
                                  <h3><a href="https://krishijagran.com/animal-husbandry/dairy-development-schemes-of-government-of-india/?amp=1">Dairy Development Scheme</a></h3>
                                  <p><p><span style="font-size:11.0pt;line-height:&#xA;107%;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;&#xA;mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:&#xA;minor-latin;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-bidi-theme-font:minor-bidi;&#xA;mso-ansi-language:EN-GB;mso-fareast-language:EN-US;mso-bidi-language:AR-SA" lang="EN-GB">The objective of this scheme is to Develop dairy sector in Punjab. This scheme is only applicable in Punjab farmers from other states are not eligible for this scheme.</span></p></p>
                                </div>
                                <div class="col-md-3">
                                  <a href="https://krishijagran.com/animal-husbandry/dairy-development-schemes-of-government-of-india/?amp=1" class="btn-yellow2 w-100">Enquire Now</a>
                                </div>
                              </div>
                            </div>
                          </div>						
                         
                         
                      						
                            
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
          
          <script type="text/javascript">
              var IS_IPAD = navigator.userAgent.match(/iPad/i) != null,
              IS_IPHONE = !IS_IPAD && ((navigator.userAgent.match(/iPhone/i) != null) || (navigator.userAgent.match(/iPod/i) != null)),
              IS_IOS = IS_IPAD || IS_IPHONE,
              IS_ANDROID = !IS_IOS && navigator.userAgent.match(/android/i) != null,
              IS_MOBILE = IS_IOS || IS_ANDROID;
              if(IS_IPAD || IS_IPHONE) 
              {
                   $(".app-popup-ios").addClass("active");
              }
              else if(IS_ANDROID)
              {	
                   $(".app-popup-android").addClass("active");
              }
              $(document).ready(function(){
                  $('#app-modal').modal('show');
                  var width = $(window).width();
                  if (width < 1199) {
                      $('#app-modal').modal('hide');
                  }
              });
              // Mobile Popup
              $(".app-popup-m-close").click(function() {
                  $(".app-popup-m").removeClass("active");
              });
          </script>
         
</body>
</html>