<?php
	if(isset($_SESSION['logged_in']) AND $_SESSION['logged_in'] == 1)
	{
		$loginProfile = "My Profile: ". $_SESSION['Username'];
		$logo = "glyphicon glyphicon-user";
		if($_SESSION['Category']!= 1)
		{
			$link = "Login/profile.php";
		}
		else {
				$link = "profileView.php";
		}
	}
	else
	{
		$loginProfile = "Login";
		$link = "index.php";
		$logo = "glyphicon glyphicon-log-in";
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <meta charset="UTF-8">
		<title>AgroCulture</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href="bootstrap\css\bootstrap.min.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="bootstrap\js\bootstrap.min.js"></script>
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="login.css"/>
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		<link rel="stylesheet" href="indexfooter.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
<style>

    
<style>

    *{
        box-sizing: border-box;
    }
    body{
        background-color: #02894B;
    }
     
.head{
    width: 100%;
    padding: 10px;
    text-align: center;
    color: #f1f1f1;
    margin-bottom: 60px;
    margin-top: 60px;
}


.card{
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition:0.3s;
  width:20%;
  border-radius:5px;
  margin:20px;
  padding-bottom:10px ;
  display: inline-block
  

}
.card:hover{
  box-shadow: 0px 20px 40px 0px rgba(0,0,0,0.2);
}

img{
  border-radius: 5px 5px 0 0 ;
  height:250px;
}
.btn{
  width:350px;
  font-size:20px;
}
.container{
  padding: 2px 16px;
  
  
}
.card-1{
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition:0.3s;
  width:20%;
  border-radius:5px;
  margin:20px;
  padding-bottom:10px ;
  display: inline-block;
  margin-left:125px;
}
.card-1:hover{
  box-shadow: 0px 20px 40px 0px rgba(0,0,0,0.2);
}
</style>

    
</head>
<body>


    <header id="header">
        <h1><a href="index.php">AgroCulture</a></h1>
        <nav id="nav">
            <ul>
            <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
						
						<li><a href="vegitable-framing.php"><span class="glyphicon glyphicon-grain"> Vegitable-Farming</a></li>
					<li><a href="fruit-farming.php"><span class="glyphicon glyphicon-grain"> Fruit-Farming</a></li>
					<li><a href="grain-farming.php"><span class="glyphicon glyphicon-grain"> Grain-Farming</a></li>
					<li><a href="animal-husbandary.php"><span class="glyphicon glyphicon-grain"> Animal-Husbandary</a></li>
						<li><a href="schems.php"><span class="glyphicon glyphicon-grain"> Govt-Schemes</a></li>
						<li><a href="blogView.php"><span class="glyphicon glyphicon-comment"> Blog</a></li>
                
                <li><a href="<?= $link; ?>"><span class="<?php echo $logo; ?>"></span><?php echo" ". $loginProfile; ?></a></li>
                
                

            </ul>
        </nav>
    </header>
    <h1 class="head">
        ANIMAL - HUSBANDRY
    </h1>
    <section>
     <div class="card-1">
     <img src="Animal-img/1681817178096.jpg" style="width:100%">
     <div class="container">
    <a href="cow-farmin-information.html">
     <button class="btn">INFORMATION</button></br>
</a>
      <a href="cow-farming-video.html" >
      <button class="btn">
        
          VIDEO
        
      </button>
</a>
</div>

</div>
<div class="card">
     <img src="Animal-img/1681816316024.jpg" style="width:100%">
     <div class="container">
    <a href="bee-farming-information.html">
     <button class="btn">INFORMATION</button></br>
</a>
    <a href="bee-framing-video.html">
     <button class="btn">VIDEO</button>
</a>
</div>
</div>
<div class="card">
     <img src="Animal-img/1681816260503.jpg" style="width:100%">
     <div class="container">
    <a href="got-farming-information.html">
     <button class="btn">INFORMATION</button></br>
</a>
    <a href="got-farming-video.html">
      <button class="btn">VIDEO</button>
</a>
</div>
</div>
<div class="card">
     <img src="Animal-img/1681816354025.jpg" style="width:100%">
     <div class="container">
     <a href="poltry-farming-information.html"> 
     <button class="btn">INFORMATION</button></br>
</a>
    <a href="poltry-fram-video.html">
      <button class="btn">VIDEO</button>
</a>
</div>
</div>
</section>
    	


                        </body>
                        </html>