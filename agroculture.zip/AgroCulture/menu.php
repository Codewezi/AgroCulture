<?php
	if(isset($_SESSION['logged_in']) AND $_SESSION['logged_in'] == 1)
	{
		$loginProfile = "My Profile: ". $_SESSION['Username'];
		$logo = "glyphicon glyphicon-user";
		if($_SESSION['Category']!= 1)
		{
			$link = "Login/profile.php";
		}
		else {
				$link = "profileView.php";
		}
	}
	else
	{
		$loginProfile = "Login";
		$link = "index.php";
		$logo = "glyphicon glyphicon-log-in";
	}
?>

<!DOCTYPE html >
			<header id="header">
				<h1><a href="index.php">AgroCulture</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
						
						<li><a href="vegitable-framing.php"><span class="glyphicon glyphicon-grain"> Vegitable-Farming</a></li>
					<li><a href="fruit-farming.php"><span class="glyphicon glyphicon-grain"> Fruit-Farming</a></li>
					<li><a href="grain-farming.php"><span class="glyphicon glyphicon-grain"> Grain-Farming</a></li>
					<li><a href="animal-husbandary.php"><span class="glyphicon glyphicon-grain"> Animal-Husbandary</a></li>
						<li><a href="schems.php"><span class="glyphicon glyphicon-grain"> Govt-Schemes</a></li>
						<li><a href="blogView.php"><span class="glyphicon glyphicon-comment"> Blog</a></li>
						
						<li><a href="<?= $link; ?>"><span class="<?php echo $logo; ?>"></span><?php echo" ". $loginProfile; ?></a></li>
						
						

					</ul>
				</nav>
			</header>

	</body>
</html>
